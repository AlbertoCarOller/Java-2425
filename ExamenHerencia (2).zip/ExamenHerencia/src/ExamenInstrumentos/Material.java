package ExamenInstrumentos;

public enum Material {
    MADERA, METAL, PLASTICO, OTRO
}