package ExamenInstrumentos;

public enum Familia {
    CUERDA, VIENTO, PERCUSION
}