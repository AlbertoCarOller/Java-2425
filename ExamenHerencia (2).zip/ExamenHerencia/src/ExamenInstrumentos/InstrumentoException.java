package ExamenInstrumentos;

public class InstrumentoException extends Exception {
    public InstrumentoException(String message) {
        super(message);
    }
}