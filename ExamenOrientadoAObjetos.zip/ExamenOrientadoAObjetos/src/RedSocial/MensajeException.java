package RedSocial;

public class MensajeException extends Exception{
    public MensajeException(String message) {
        super(message);
    }
}