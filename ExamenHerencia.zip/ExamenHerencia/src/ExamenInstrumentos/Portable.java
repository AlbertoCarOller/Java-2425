package ExamenInstrumentos;

public interface Portable {

    // Hacemos un método, en este caso será mostrarFacilidad
    boolean mostrarFacilidad();
}