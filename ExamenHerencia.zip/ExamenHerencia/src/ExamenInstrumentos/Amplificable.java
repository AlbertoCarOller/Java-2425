package ExamenInstrumentos;

public interface Amplificable {

    // Creamos dos métodos
    void conectarAmplificador();
    void ajustarVolumen();
}