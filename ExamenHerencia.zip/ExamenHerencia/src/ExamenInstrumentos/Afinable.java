package ExamenInstrumentos;

public interface Afinable {

    // Hacemos un método para posteriormente heredarlo en las clases que lo implementen
    void afinar();
}