package ExamenInstrumentos;

public interface Tocable {

    // Hacemos un método para después implementarlo en las clases o clase que lo hereden
    void tocar();
}