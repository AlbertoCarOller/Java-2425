package ExamenInstrumentos;

import java.util.ArrayList;
import java.util.List;

public class InstrumentoApp {
    static List<Instrumento> instrumentos = new ArrayList<>();

    public static void main(String[] args) {
        try {
            // Creamos los instrumentos y los añadimos a la lista de instrumentos
            instrumentos.add(new GuitarraAcustica("Guitarra española", Material.MADERA, false, 2.5));
            instrumentos.add(new GuitarraElectrica("Fender Stratocaster", Material.METAL, true, 3.5));
            instrumentos.add(new Piano("Yamaha Clavinova", Material.MADERA, false));
            instrumentos.add(new Flauta("ExamenInstrumentos.Flauta dulce", Material.PLASTICO, true, 0.5));
            instrumentos.add(new Bateria("Batería acústica", Material.METAL, false));
            // Llamamos al método para comprobar el tipo y llamar a sus respectivos métodos
            llamarMetodos();
        } catch (InstrumentoException e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Este método va a recorrer la lista de instrumentos identificando las interfaces que
     * implementan y llamando a sus respectivos métodos
     */
    public static void llamarMetodos() {
        for (Instrumento instrumento : instrumentos) {
            if (instrumento instanceof Portable portable) {
                if (portable.mostrarFacilidad()) {
                    System.out.println(instrumento.getNombre() + " es portable");

                } else {
                    System.out.println(instrumento.getNombre() + " no es portable");
                }
            }
            if (instrumento instanceof Amplificable amplificable) {
                amplificable.conectarAmplificador();
                amplificable.ajustarVolumen();
            }
            instrumento.afinar();
            if (instrumento.isAfinado()) {
                System.out.println(instrumento.getNombre() + " está afinado");

            } else {
                System.out.println(instrumento.getNombre() + " no está afinado");
            }
            instrumento.tocar();
        }
    }
}